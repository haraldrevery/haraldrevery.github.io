let config = {
    rootDir: './tests/jest',
}

module.exports = config
