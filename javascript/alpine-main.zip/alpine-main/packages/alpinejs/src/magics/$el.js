import { magic } from "../magics";

magic('el', el => el)
