import { getStores } from '../store'
import { magic } from '../magics'

magic('store', getStores)
