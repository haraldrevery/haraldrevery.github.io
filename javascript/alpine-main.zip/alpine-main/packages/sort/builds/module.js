import sort  from '../src/index.js'

export default sort

export { sort }
