import focus from '../src/index.js'

export default focus

export { focus }
