---
order: 7
title: Plugins
font-type: mono
type: sub-directory
---
