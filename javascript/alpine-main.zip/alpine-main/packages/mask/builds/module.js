import mask, { stripDown } from '../src/index.js'

export default mask

export { mask, stripDown }
