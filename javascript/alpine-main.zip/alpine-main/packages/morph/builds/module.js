import morph from '../src/index.js'

export default morph

export { morph }
