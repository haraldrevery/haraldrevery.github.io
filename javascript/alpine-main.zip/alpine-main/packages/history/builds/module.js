import history from '../src/index.js'
import { track } from '../src/index.js'

export default history

export { history, track }
