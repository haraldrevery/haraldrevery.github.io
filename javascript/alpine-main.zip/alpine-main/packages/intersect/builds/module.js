import intersect from './../src/index.js'

export default intersect

export { intersect }
