import navigate from '../src/index.js'

export default navigate

export { navigate }
