import anchor from '../src/index.js'

export default anchor

export { anchor }
