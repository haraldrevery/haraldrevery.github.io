import * as all from './factoriesAny.js'
import { create } from './core/create.js'

export default create(all)
