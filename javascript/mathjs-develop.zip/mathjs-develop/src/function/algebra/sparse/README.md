# CSparse

This folder contains a JavaScript port of the `CSparse` section of the open source `SuiteSparse` library by Timothy A. Davis, see:

https://github.com/DrTimothyAldenDavis/SuiteSparse/tree/dev/CSparse/Source


```
CSparse: a Concise Sparse matrix package.
Copyright (c) 2006, Timothy A. Davis.
http://www.suitesparse.com
```
