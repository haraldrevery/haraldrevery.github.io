# Code Editor Example

This is an example for using [mathjs](https://mathjs.org) with a code editor.

To run your own you need to install the dependancies with.
```
npm install
```

You can start development mode with:
```
npm run dev
```

Or build the project with:
```
npm run build
```